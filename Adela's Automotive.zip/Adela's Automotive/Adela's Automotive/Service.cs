﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adela_s_Automotive
{
    class Service
    {
        private double _total;
        private double _tax;
        private double _part;
        private double _services;
        private double _labor;

        public const double COSTOFLABOR = 80.00;

        public Service()
        {
                
        }
        public Service(double labor)
        {
            _labor = labor; 
        }

        public double Total { get { return _total; } set { _total = value; } }

        public double Tax { get { return _tax; } set { _tax = value; } }

        public double Part { get { return _part; } set { _part = value; } }

        public double Services { get { return _services; } set { _services = value; } }

        public double Labor { get { return _labor; } set { _labor = value; } }

        public double CostOfLabor()
        {
            return _labor * COSTOFLABOR; 
        }

    }
}
