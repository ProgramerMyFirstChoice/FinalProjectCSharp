﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adela_s_Automotive
{
    class Validator
    {
        private string title = "Entry Error";

        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }
        public bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(textBox.Tag + " is a required field.", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }
        public bool IsDouble(TextBox textBox)
        {
            if (Double.TryParse(textBox.Text, out double number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }
        public bool IsDecimal(TextBox textBox)
        {
            if (Decimal.TryParse(textBox.Text, out decimal number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Title);
                textBox.Focus();
                return false;
            }
        }
        public bool IsInt32(TextBox textBox)
        {
            if (Int32.TryParse(textBox.Text, out int number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be an integer.", Title);
                textBox.Focus();
                return false;
            }
        }
        public bool IsWithinRange(TextBox textBox, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number < min || number > max)
            {
                MessageBox.Show(textBox.Tag + " must be between " + min + " and " + max + ".", Title);
                textBox.Focus();
                return false;
            }
            return true;
        }
    }
}
