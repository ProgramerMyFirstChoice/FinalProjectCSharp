﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adela_s_Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Service serv = new Service();
        
        Validator valide = new Validator();

        List<Service> listService = new List<Service>();

        const double TAX = 0.06;
        
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                /* 
                 * created a field, property for each of
                 * the variables total, tax, part, service
                 * with get and set so they can be
                 * manipulated
                 */
                double total = 0;
                double tax = 0;
                double part = 0;
                double service = 0;
                double labor = 0;
                double costOfLabor = 0;
                double costOfLaborAndService = 0;

                /* created a field, property for each of the checkboxes
                 * used only the get property for checkboxes
                 * the user does not need to change the values
                 */
                //create a method to calculate the cost of oil & lube
                if (chkOil.Checked)
                {
                    service += 26.00;
                }
                if (chkLube.Checked)
                {
                    service += 18.00;
                }
                //create method to calculate the cost of flushes
                if (chkRadiator.Checked)
                {
                    service += 30.00;
                }

                if (chkTransmission.Checked)
                {
                    service += 80.00;
                }
                //create method to calculate the cost of misc services
                if (chkInspection.Checked)
                {
                    service += 15.00;
                }

                if (chkMuffler.Checked)
                {
                    service += 100.00;
                }

                if (chkTire.Checked)
                {
                    service += 20.00;
                }
                //create method to calculate labor
                //when user enters hours worked
                //at $80 an hour
                if (valide.IsPresent(txtLabor))
                {
                    if (valide.IsDouble(txtLabor))
                    {
                        labor = Convert.ToDouble(txtLabor.Text);
                        Service laborhour = new Service(labor);

                        costOfLabor = laborhour.CostOfLabor();

                    }

                }

                costOfLaborAndService = service + costOfLabor;
                //create method to calculate the parts
                //and tax if needed     

                part = double.Parse(txtPart.Text);

                tax = (part * TAX);

                total = costOfLaborAndService + part + tax;
                

                //display the cost of labor and service
                //parts, tax on the parts and grand total
                txtService.Text = costOfLaborAndService.ToString("c2");
                txtSummaryParts.Text = part.ToString("c2");
                txtTax.Text = tax.ToString("c2");
                txtTotal.Text = total.ToString("c2");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            chkOil.Checked = false;
            chkLube.Checked = false;
            chkRadiator.Checked = false;
            chkTransmission.Checked = false;
            chkInspection.Checked = false;
            chkMuffler.Checked = false;
            chkTire.Checked = false;
            txtPart.Clear();
            txtLabor.Clear();
            txtService.Clear();
            txtSummaryParts.Clear();
            txtTax.Clear();
            txtTotal.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the application
            this.Close();
        }

        public void CalcualteOilLube()
        {

        }

        double subTotal = 0;

        private void chkOil_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        // Method to validate the user input textbox
        public bool IsValidData()
        {
            return
            // Validate Part
             valide.IsDouble(txtPart) &&
            // validate labor
            valide.IsDouble(txtLabor) &&
            valide.IsPresent(txtLabor); 
        }
    }
}
